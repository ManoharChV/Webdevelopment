﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCDemoApp.Models
{
    public class DeptModel

    {

        public int DeptNo { get; set; }
        public string Dname { get; set; }
        public string Loc { get; set; }
     }
}