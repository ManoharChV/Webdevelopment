﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MVCDemoApp.Models
{
    public class Employee
    {
        //int number;
        //string name;
        //double salary;
        [Required(ErrorMessage = "Employee Id is required")]
        public int? Number { get; set; }
        [Required(ErrorMessage = "Employee Name is required")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Employee Salary is required")]
        public double? Salary { get; set; }
        //public int? Number { get { return number; } set { number = value; } }
        //[Required(ErrorMessage = "Employee Name is required")]
        //public string Name{ get { return name; } set { name = value; } }
        //[Required(ErrorMessage = "Employee Salary is required")]
        //public double? Salary{ get { return salary; } set { salary = value; } }
    }
}