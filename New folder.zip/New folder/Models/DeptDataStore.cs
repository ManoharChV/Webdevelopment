﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace MVCDemoApp.Models
{
    public class DeptDataStore
    {
        public List<DeptModel> GetDeptDataDB()
        {
            SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["connstr"].ConnectionString);
            string sql = "Select * from dept";
            SqlDataAdapter adapter = new SqlDataAdapter(sql, connection);
            DataSet ds = new DataSet();
            adapter.Fill(ds, "dept");
            List<DeptModel> deptlist = new List<DeptModel>();
            for (int i = 0; i < ds.Tables["dept"].Rows.Count; i++)
            {
                DeptModel dept = new DeptModel();
                dept.DeptNo = (int)ds.Tables["dept"].Rows[i]["DeptNo"];
                dept.Dname = ds.Tables["dept"].Rows[i]["Dname"].ToString();
                dept.Loc = ds.Tables["dept"].Rows[i]["Loc"].ToString();
                deptlist.Add(dept);
            }
            return deptlist;

        }
    }
}