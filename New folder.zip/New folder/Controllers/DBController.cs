﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;
using System.Data;
using MVCDemoApp.Models;

namespace MVCDemoApp.Controllers
{
    public class DBController : Controller
    {
        // Disconnected Dept
        public ActionResult GetDepartmentData()
        {
            DeptDataStore ds = new DeptDataStore();
            List<DeptModel> deptlist = new List<DeptModel>();
           deptlist= ds.GetDeptDataDB();
            return View(deptlist);
        }
    }
}