﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVCDemoApp.Models;

namespace MVCDemoApp.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
        [Route("Home/Greet/{n1?}")]
        public ActionResult Greet(string id)
        {
            ViewBag.msg = "hi" + id;
            return View();
        }
        [Route("Home/Add/{num1?}/{num2?}")]
        public ActionResult Add(int num1 = 0, int num2 = 0)
        {
            ViewBag.result = num1 + num2;
            return View();
        }
        [Route("Home/Employee")]
        public ActionResult Employee()
        {
            Employee employee = new Employee() { Number = 101, Name = "manohar", Salary = 30000 };
            ViewBag.emp = employee;
            return View();
        }
        public ActionResult ModelDemoBinder()
        {
            Employee employee = new Employee() { Number = 101, Name = "Manohar", Salary = 50000 };
            return View(employee);
        }

        public ActionResult ModelDemoBinderCollection()

        {
            List<Employee> emplist = new List<Employee>();
            emplist.Add(new Employee() { Number = 101, Name = "Manohar", Salary = 50000 });
            emplist.Add(new Employee() { Number = 102, Name = "Yashwanth", Salary = 40000 });
            emplist.Add(new Employee() { Number = 103, Name = "abhishek", Salary = 30000 });
            return View(emplist);

        }
        public ActionResult EmployeeForm()
        {
            return View(new Employee());
        }
        public ActionResult PostEmployeeData(Employee employee)
        {
            if (ModelState.IsValid)
                return View(employee);
            else
                return View("EmployeeForm", employee);

        }
    }

}